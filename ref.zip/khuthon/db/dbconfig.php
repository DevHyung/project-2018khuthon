<?php
$db = mysqli_connect('localhost','root','root','psm');
if(mysqli_connect_errno()){
	echo "연결에러 ";
}
?>