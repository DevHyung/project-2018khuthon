<?php
require_once("./dbconfig.php");
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

$userId=$_POST['userId'];
$userPw=$_POST['userPw'];
$table_name = "user";
$sql = "SELECT * FROM $table_name WHERE id='$userId'";
// 
if($result = mysqli_query($db, $sql))
{
	if(mysqli_num_rows($result) == 0)
	{
		echo "<script>alert('No matched ID.');</script>";
		echo "<script>window.location.replace('../index.html');</script>";
	}
	else
	{
		$row = mysqli_fetch_assoc($result);
		if($row["pw"] == $userPw) // 로그인 성공
		{
			$_SESSION['auth'] = $row['isVerify'];
			$_SESSION['name'] = $row['name'];
			// [TEST] auth 테스트 코드
			if ( $_SESSION['auth'] == 0 )
				echo "<script>alert('사장님');</script>";
			elseif ($_SESSION['auth'] == 1) 
				echo "<script>alert('팀장급');</script>";
			elseif ($_SESSION['auth'] == 2) 
				echo "<script>alert('직원');</script>";
			elseif ($_SESSION['auth'] == 3) 
				echo "<script>alert('거래처');</script>";
			// 테스트코드 끝

			echo "<script>alert('Success');</script>";
			echo "<script>window.location.replace('../page/index.php');</script>";
		}
		else
		{
			echo "<script>alert('Wrong Password.');</script>";
			echo "<script>window.location.replace('../index.html');</script>";
		}
	}
}
mysqli_free_result($result);
mysqli_close($db);
?>