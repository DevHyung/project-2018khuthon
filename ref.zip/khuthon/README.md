# marketing-ERP

## 완성페이지
- [x] 로그인 http://127.0.0.1/psm/index.html
- [x] 로그인 체크 
- [x] 로그인 확인 및 회원관리
## 진행페이지
- [x] 권한 오르락 내리락 부분 user_list.php 맨아래 추가 
- [x] 기타 다른 페이지
## 대행 업체 
- [x] 조회 ** 항목 점검 받아야함 ** 
- [x] 등록 ** 항목 점검 받아야함 ** 
- [ ] 삭제 ** 삭제 있어야할까 ? **
- [ ] 수정 
- [ ] 대행업체들이 들어와서 쓰는곳

## DB 
```SQL
# create schema
CREATE DATABASE `psm` /*!40100 DEFAULT CHARACTER SET utf8 */;
#user
CREATE TABLE `user` (
  `id` varchar(45) NOT NULL,
  `pw` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `isVerify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# agent
CREATE TABLE `agent` (
  `idx` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `manager` varchar(45) DEFAULT NULL,
  `tel` varchar(45) DEFAULT NULL,
  `messenger` varchar(45) DEFAULT NULL,
  `sDate` date DEFAULT NULL,
  `eDate` date DEFAULT NULL,
  `category` varchar(45) DEFAULT NULL,
  `etc` text,
  `isSave` varchar(10) DEFAULT NULL,
  `registerDate` datetime DEFAULT NULL,
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

```
